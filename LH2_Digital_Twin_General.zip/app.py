import copy
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from physics import (
    SimParams,
    run_simulation,
    assess_status,
    RHO_LIQUID_H2,
    H_FG_H2,
    T_NBP,
)

st.set_page_config(
    page_title="LH2 Storage Tank Digital Twin",
    page_icon="🧊",
    layout="wide",
)

st.markdown(
    """
    <style>
    .main .block-container {padding-top: 1.2rem; padding-bottom: 2rem;}
    div[data-testid="stMetric"] {
        border: 1px solid rgba(128,128,128,0.22);
        padding: 14px;
        border-radius: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("🧊 Liquid Hydrogen (LH₂) Storage Tank — Digital Twin")
st.caption(
    "General engineering digital-twin prototype for predicting thermal behavior, "
    "boil-off, pressure rise and venting risk during LH₂ storage."
)

with st.expander("Model assumptions"):
    st.markdown(
        f"""
- 0-D lumped transient tank model.
- Liquid + vapor/ullage phases are represented.
- Heat ingress is converted to boil-off using an approximate latent heat:
  **{H_FG_H2/1000:.1f} kJ/kg**.
- Liquid hydrogen density is approximated as **{RHO_LIQUID_H2:.1f} kg/m³**.
- Vapor pressure is estimated using an ideal-gas ullage model.
- Tank temperature is approximated from a simplified saturation relation.
- Venting begins at the user-defined vent pressure.
- Heat ingress can be represented using **UA × ΔT** or a fixed heat-leak value.
- This is a prototype, not a certified plant-safety model.
        """
    )

# ---------------- INPUTS ----------------
st.sidebar.header("Tank Conditions")

V_tank = st.sidebar.number_input(
    "Tank total volume (m³)",
    min_value=0.1,
    max_value=100000.0,
    value=50.0,
    step=1.0,
)

fill_level = st.sidebar.slider(
    "Initial LH₂ fill level (%)",
    1.0,
    99.0,
    80.0,
    step=1.0,
)

P_init = st.sidebar.number_input(
    "Initial tank pressure (bar abs)",
    min_value=0.05,
    max_value=13.0,
    value=1.5,
    step=0.05,
)

T_init = st.sidebar.slider(
    "Initial LH₂ temperature (K)",
    14.0,
    33.0,
    21.0,
    step=0.1,
)

T_amb_C = st.sidebar.slider(
    "Ambient temperature (°C)",
    -50.0,
    60.0,
    20.0,
    step=1.0,
)

st.sidebar.header("Storage Duration")

duration_unit = st.sidebar.radio(
    "Duration unit",
    ["hours", "days"],
    horizontal=True,
)

duration_val = st.sidebar.number_input(
    f"Storage duration ({duration_unit})",
    min_value=0.1,
    value=72.0 if duration_unit == "hours" else 3.0,
    step=1.0,
)

duration_h = duration_val if duration_unit == "hours" else duration_val * 24.0

st.sidebar.header("Heat Leak / Insulation")

heat_mode_label = st.sidebar.radio(
    "Heat input mode",
    ["UA (W/K)", "Fixed heat leak (W)"],
)

heat_input_mode = "UA" if heat_mode_label.startswith("UA") else "FIXED_LEAK"

if heat_input_mode == "UA":
    UA = st.sidebar.number_input(
        "Overall UA (W/K)",
        min_value=0.0,
        max_value=10000.0,
        value=5.0,
        step=0.5,
    )
    Q_leak_fixed = 0.0
else:
    Q_leak_fixed = st.sidebar.number_input(
        "Fixed total heat leak (W)",
        min_value=0.0,
        max_value=1_000_000.0,
        value=500.0,
        step=10.0,
    )
    UA = 0.0

st.sidebar.header("Pressure Limit")

P_vent = st.sidebar.number_input(
    "Venting pressure limit (bar abs)",
    min_value=0.2,
    max_value=15.0,
    value=5.0,
    step=0.1,
)

safety_margin = st.sidebar.slider(
    "Safety margin below vent limit (bar)",
    0.0,
    3.0,
    0.3,
    step=0.1,
)

with st.sidebar.expander("Advanced"):
    dt_s = st.number_input(
        "Simulation time step (s)",
        min_value=1.0,
        max_value=3600.0,
        value=60.0,
        step=1.0,
    )

params = SimParams(
    V_tank_m3=V_tank,
    fill_level_pct=fill_level,
    P_init_bar=P_init,
    T_init_K=T_init,
    T_ambient_C=T_amb_C,
    duration_h=duration_h,
    heat_input_mode=heat_input_mode,
    UA_W_per_K=UA,
    Q_leak_fixed_W=Q_leak_fixed,
    P_vent_bar=P_vent,
    safety_margin_bar=safety_margin,
    dt_s=dt_s,
)

try:
    params.validate()
except ValueError as e:
    st.error(str(e))
    st.stop()

result = run_simulation(params)
status = assess_status(params, result)

status_style = {
    "GREEN": ("🟢", "#1e7e34"),
    "YELLOW": ("🟡", "#b8860b"),
    "RED": ("🔴", "#c0392b"),
}

icon, color = status_style[status["status"]]

st.markdown(
    f"""
    <div style="padding:14px 20px;border-radius:12px;
    background-color:{color}18;border:2px solid {color};margin-bottom:12px;">
      <span style="font-size:26px;">{icon}</span>
      <span style="font-size:22px;font-weight:700;color:{color};">
        {status['label']}
      </span>
      <div style="margin-top:6px;">{status['message']}</div>
    </div>
    """,
    unsafe_allow_html=True,
)

# ---------------- SUMMARY ----------------
c1, c2, c3, c4 = st.columns(4)

c1.metric(
    "Initial pressure",
    f"{result['P_bar'][0]:.2f} bar(a)",
)

c2.metric(
    "Predicted max pressure",
    f"{result['max_pressure_bar']:.2f} bar(a)",
)

ttv = result["time_to_vent_h"]

c3.metric(
    "Time to vent",
    f"{ttv:.2f} h" if ttv is not None else "No vent predicted",
)

c4.metric(
    "Initial boil-off rate",
    f"{result['boiloff_rate_kg_h_initial']:.2f} kg/h",
    f"{result['boiloff_pct_per_day_initial']:.3f} %/day",
)

c5, c6, c7 = st.columns(3)

c5.metric(
    "Total boil-off generated",
    f"{result['total_bog_kg']:.1f} kg",
)

c6.metric(
    "Total vented H₂",
    f"{result['total_vented_kg']:.1f} kg",
)

c7.metric(
    "Final LH₂ inventory",
    f"{result['final_liquid_kg']:.1f} kg",
)

st.divider()

# ---------------- CHARTS ----------------
st.subheader("Digital Twin Predictions")

tab1, tab2, tab3, tab4 = st.tabs(
    [
        "Pressure",
        "Boil-off",
        "Inventory",
        "Heat Ingress",
    ]
)

t_h = result["t_h"]

with tab1:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=t_h,
            y=result["P_bar"],
            mode="lines",
            name="Tank pressure",
        )
    )
    fig.add_hline(
        y=P_vent,
        line_dash="dash",
        annotation_text="Vent limit",
    )
    fig.add_hline(
        y=P_vent - safety_margin,
        line_dash="dot",
        annotation_text="Safety margin",
    )
    fig.update_layout(
        xaxis_title="Time (h)",
        yaxis_title="Pressure (bar abs)",
        height=430,
    )
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=t_h,
            y=result["mdot_bog_kg_h"],
            mode="lines",
            name="Boil-off rate",
        )
    )
    fig.update_layout(
        xaxis_title="Time (h)",
        yaxis_title="Boil-off rate (kg/h)",
        height=430,
    )
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=t_h,
            y=result["m_liquid_kg"],
            mode="lines",
            name="LH₂ liquid mass",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=t_h,
            y=result["m_vapor_kg"],
            mode="lines",
            name="Vapor mass",
        )
    )
    fig.update_layout(
        xaxis_title="Time (h)",
        yaxis_title="Mass (kg)",
        height=430,
    )
    st.plotly_chart(fig, use_container_width=True)

with tab4:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=t_h,
            y=result["Q_in_W"],
            mode="lines",
            name="Heat ingress",
        )
    )
    fig.update_layout(
        xaxis_title="Time (h)",
        yaxis_title="Heat ingress (W)",
        height=430,
    )
    st.plotly_chart(fig, use_container_width=True)

st.divider()

# ---------------- GENERAL SCENARIO STUDY ----------------
st.subheader("Scenario Comparison")

st.caption(
    "Use this section to study how ambient temperature, insulation/UA, "
    "fill level and storage duration affect tank behavior."
)

default_scenarios = pd.DataFrame(
    [
        {
            "Scenario": "Baseline",
            "Ambient T (°C)": T_amb_C,
            "UA (W/K)": UA,
            "Fill level (%)": fill_level,
            "Duration (h)": duration_h,
        },
        {
            "Scenario": "Higher ambient temperature",
            "Ambient T (°C)": T_amb_C + 10,
            "UA (W/K)": UA,
            "Fill level (%)": fill_level,
            "Duration (h)": duration_h,
        },
        {
            "Scenario": "Higher heat leakage",
            "Ambient T (°C)": T_amb_C,
            "UA (W/K)": UA * 2,
            "Fill level (%)": fill_level,
            "Duration (h)": duration_h,
        },
        {
            "Scenario": "Longer storage",
            "Ambient T (°C)": T_amb_C,
            "UA (W/K)": UA,
            "Fill level (%)": fill_level,
            "Duration (h)": duration_h * 2,
        },
    ]
)

scenario_df = st.data_editor(
    default_scenarios,
    num_rows="dynamic",
    use_container_width=True,
    key="scenario_editor_general",
)

if st.button("▶ Run scenario comparison"):
    rows = []

    for _, row in scenario_df.iterrows():
        try:
            p = copy.deepcopy(params)
            p.T_ambient_C = float(row["Ambient T (°C)"])
            p.UA_W_per_K = float(row["UA (W/K)"])
            p.heat_input_mode = "UA"
            p.fill_level_pct = float(row["Fill level (%)"])
            p.duration_h = float(row["Duration (h)"])
            p.validate()

            r = run_simulation(p)

            rows.append(
                {
                    "Scenario": row["Scenario"],
                    "Max pressure (bar)": round(r["max_pressure_bar"], 2),
                    "Time to vent (h)": (
                        round(r["time_to_vent_h"], 2)
                        if r["time_to_vent_h"] is not None
                        else "No vent"
                    ),
                    "Initial boil-off (kg/h)": round(
                        r["boiloff_rate_kg_h_initial"], 2
                    ),
                    "Total vented (kg)": round(r["total_vented_kg"], 1),
                    "Final LH₂ mass (kg)": round(r["final_liquid_kg"], 1),
                }
            )

        except ValueError as e:
            rows.append(
                {
                    "Scenario": row.get("Scenario", "Unnamed"),
                    "Max pressure (bar)": "Invalid",
                    "Time to vent (h)": str(e),
                    "Initial boil-off (kg/h)": "-",
                    "Total vented (kg)": "-",
                    "Final LH₂ mass (kg)": "-",
                }
            )

    results_df = pd.DataFrame(rows)
    st.dataframe(results_df, use_container_width=True, hide_index=True)

    numeric_rows = results_df[
        pd.to_numeric(
            results_df["Max pressure (bar)"],
            errors="coerce",
        ).notna()
    ]

    if not numeric_rows.empty:
        fig = go.Figure()
        fig.add_trace(
            go.Bar(
                x=numeric_rows["Scenario"],
                y=numeric_rows["Max pressure (bar)"],
            )
        )
        fig.add_hline(
            y=P_vent,
            line_dash="dash",
            annotation_text="Vent limit",
        )
        fig.update_layout(
            yaxis_title="Max predicted pressure (bar abs)",
            height=380,
        )
        st.plotly_chart(fig, use_container_width=True)

st.divider()

st.caption(
    "⚠️ This digital twin is a general engineering prototype for monitoring, "
    "prediction and scenario analysis. It does not prescribe a specific mitigation "
    "method and is not a certified safety model."
)
