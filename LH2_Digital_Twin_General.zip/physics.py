from dataclasses import dataclass
import math
import numpy as np

R_UNIVERSAL = 8.314462618
M_H2 = 2.01588e-3
R_H2 = R_UNIVERSAL / M_H2

RHO_LIQUID_H2 = 70.8       # kg/m3
H_FG_H2 = 445_000.0        # J/kg
T_NBP = 20.27              # K
CC_B = H_FG_H2 / R_H2


def celsius_to_kelvin(T_C: float) -> float:
    return T_C + 273.15


def saturation_temperature_K(P_bar: float) -> float:
    if P_bar <= 0:
        raise ValueError("Pressure must be positive.")
    P_ref_bar = 1.01325
    denom = (1.0 / T_NBP) - math.log(P_bar / P_ref_bar) / CC_B
    if denom <= 0:
        return 33.0
    return 1.0 / denom


def compressibility_factor(P_bar: float, T_K: float) -> float:
    # Prototype hook for future real-gas EOS replacement.
    return 1.0


@dataclass
class SimParams:
    V_tank_m3: float
    fill_level_pct: float
    P_init_bar: float
    T_init_K: float
    T_ambient_C: float
    duration_h: float
    heat_input_mode: str
    UA_W_per_K: float
    Q_leak_fixed_W: float
    P_vent_bar: float
    safety_margin_bar: float
    dt_s: float = 60.0

    def validate(self):
        if self.V_tank_m3 <= 0:
            raise ValueError("Tank volume must be positive.")
        if not (0 < self.fill_level_pct < 100):
            raise ValueError("Fill level must be between 0 and 100%.")
        if self.P_init_bar <= 0:
            raise ValueError("Initial pressure must be positive.")
        if self.P_vent_bar <= self.P_init_bar:
            raise ValueError("Venting pressure must be greater than initial pressure.")
        if self.duration_h <= 0:
            raise ValueError("Storage duration must be positive.")
        if self.dt_s <= 0:
            raise ValueError("Time step must be positive.")
        if self.heat_input_mode not in ("UA", "FIXED_LEAK"):
            raise ValueError("Heat input mode must be UA or FIXED_LEAK.")
        if self.UA_W_per_K < 0 or self.Q_leak_fixed_W < 0:
            raise ValueError("Heat leak values cannot be negative.")
        if self.safety_margin_bar < 0:
            raise ValueError("Safety margin cannot be negative.")


def _initial_state(params: SimParams):
    V_liq = params.V_tank_m3 * params.fill_level_pct / 100.0
    m_liq = V_liq * RHO_LIQUID_H2
    V_ullage = max(params.V_tank_m3 - V_liq, 1e-6)
    P_pa = params.P_init_bar * 1e5
    Z = compressibility_factor(params.P_init_bar, params.T_init_K)
    m_vap = P_pa * V_ullage / (Z * R_H2 * params.T_init_K)
    return m_liq, m_vap


def run_simulation(params: SimParams):
    params.validate()

    n_steps = max(2, int(math.ceil(params.duration_h * 3600 / params.dt_s)) + 1)
    t_s = np.linspace(0.0, params.duration_h * 3600.0, n_steps)

    P_bar = np.zeros(n_steps)
    T_K = np.zeros(n_steps)
    m_liq_arr = np.zeros(n_steps)
    m_vap_arr = np.zeros(n_steps)
    mdot_bog_kg_h = np.zeros(n_steps)
    Q_in_W = np.zeros(n_steps)
    vent_rate_kg_h = np.zeros(n_steps)

    m_liq, m_vap = _initial_state(params)

    P_bar[0] = params.P_init_bar
    T_K[0] = params.T_init_K
    m_liq_arr[0] = m_liq
    m_vap_arr[0] = m_vap

    total_bog = 0.0
    total_vented = 0.0
    time_to_vent_h = None

    for i in range(1, n_steps):
        dt = t_s[i] - t_s[i - 1]

        T_tank = saturation_temperature_K(max(P_bar[i - 1], 0.05))
        T_K[i - 1] = T_tank

        if params.heat_input_mode == "UA":
            q_in = max(
                0.0,
                params.UA_W_per_K
                * (celsius_to_kelvin(params.T_ambient_C) - T_tank),
            )
        else:
            q_in = max(0.0, params.Q_leak_fixed_W)

        dm_bog = min(m_liq, q_in * dt / H_FG_H2)
        m_liq = max(0.0, m_liq - dm_bog)
        m_vap = max(0.0, m_vap + dm_bog)
        total_bog += dm_bog

        V_liq = m_liq / RHO_LIQUID_H2
        V_ullage = max(params.V_tank_m3 - V_liq, 1e-6)

        P_est_bar = max(P_bar[i - 1], 0.05)
        for _ in range(5):
            T_est = saturation_temperature_K(P_est_bar)
            Z = compressibility_factor(P_est_bar, T_est)
            P_est_bar = max(
                (m_vap * Z * R_H2 * T_est / V_ullage) / 1e5,
                0.01,
            )

        if P_est_bar >= params.P_vent_bar:
            if time_to_vent_h is None:
                time_to_vent_h = t_s[i] / 3600.0

            T_vent = saturation_temperature_K(params.P_vent_bar)
            Z = compressibility_factor(params.P_vent_bar, T_vent)
            m_vap_allowed = (
                params.P_vent_bar * 1e5 * V_ullage / (Z * R_H2 * T_vent)
            )
            dm_vent = max(0.0, min(m_vap - m_vap_allowed, m_vap))
            m_vap -= dm_vent
            total_vented += dm_vent
            P_est_bar = params.P_vent_bar
            vent_rate_kg_h[i] = dm_vent / dt * 3600.0 if dt > 0 else 0.0

        P_bar[i] = P_est_bar
        T_K[i] = saturation_temperature_K(max(P_est_bar, 0.05))
        m_liq_arr[i] = m_liq
        m_vap_arr[i] = m_vap
        mdot_bog_kg_h[i] = dm_bog / dt * 3600.0 if dt > 0 else 0.0
        Q_in_W[i] = q_in

    if n_steps > 1:
        Q_in_W[0] = Q_in_W[1]
        mdot_bog_kg_h[0] = mdot_bog_kg_h[1]

    initial_liq, _ = _initial_state(params)
    initial_bor = mdot_bog_kg_h[0]
    bor_pct_day = (
        initial_bor * 24.0 / initial_liq * 100.0 if initial_liq > 0 else 0.0
    )

    return {
        "t_h": t_s / 3600.0,
        "P_bar": P_bar,
        "T_K": T_K,
        "m_liquid_kg": m_liq_arr,
        "m_vapor_kg": m_vap_arr,
        "mdot_bog_kg_h": mdot_bog_kg_h,
        "Q_in_W": Q_in_W,
        "vent_rate_kg_h": vent_rate_kg_h,
        "max_pressure_bar": float(np.max(P_bar)),
        "time_to_vent_h": time_to_vent_h,
        "boiloff_rate_kg_h_initial": float(initial_bor),
        "boiloff_pct_per_day_initial": float(bor_pct_day),
        "total_bog_kg": float(total_bog),
        "total_vented_kg": float(total_vented),
        "final_liquid_kg": float(m_liq_arr[-1]),
    }


def assess_status(params: SimParams, result: dict):
    threshold = params.P_vent_bar - params.safety_margin_bar
    max_p = result["max_pressure_bar"]
    ttv = result["time_to_vent_h"]

    if ttv is not None:
        return {
            "status": "RED",
            "label": "VENTING RISK",
            "message": (
                f"Venting is predicted after approximately {ttv:.2f} h "
                f"under the current simulated conditions."
            ),
        }

    if max_p >= threshold:
        return {
            "status": "YELLOW",
            "label": "WARNING",
            "message": (
                "The predicted pressure enters the configured safety-margin region "
                "during the requested storage period."
            ),
        }

    return {
        "status": "GREEN",
        "label": "STABLE",
        "message": (
            "The predicted pressure remains below the configured safety-margin "
            "threshold for the requested storage period."
        ),
    }
